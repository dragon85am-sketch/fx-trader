import { NextResponse } from "next/server";
import { requireAuth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
function slugify(v:string){return v.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,40)}
export async function GET(){const a=await requireAuth();if(!a.ok)return a.response;const rows=await prisma.affiliateCampaign.findMany({where:{userId:a.user.userId},orderBy:{createdAt:'desc'}});const app=process.env.NEXT_PUBLIC_APP_URL??'http://localhost:3000';const campaigns=await Promise.all(rows.map(async c=>({...c,link:`${app}/ref/${a.user.userId}?c=${encodeURIComponent(c.slug)}`,registrations:await prisma.user.count({where:{referredByUserId:a.user.userId,referredByCampaignId:c.id}})}))); const referrals=await prisma.user.findMany({where:{referredByUserId:a.user.userId},orderBy:{createdAt:'desc'},take:50,select:{id:true,name:true,createdAt:true,isPremium:true,referredByCampaignId:true}}); return NextResponse.json({campaigns,referrals:referrals.map(u=>({id:u.id,name:u.name?.trim()||'Użytkownik',createdAt:u.createdAt,isPremium:u.isPremium,campaignId:u.referredByCampaignId}))})}
export async function POST(req:Request){const a=await requireAuth();if(!a.ok)return a.response;const body=await req.json().catch(()=>({}));const name=String(body.name??'').trim().slice(0,80);if(!name)return NextResponse.json({error:'Podaj nazwę kampanii'},{status:400});let base=slugify(name)||'kampania';let slug=base;let i=2;while(await prisma.affiliateCampaign.findFirst({where:{userId:a.user.userId,slug}})){slug=`${base}-${i++}`};const campaign=await prisma.affiliateCampaign.create({data:{userId:a.user.userId,name,slug}});return NextResponse.json({campaign},{status:201})}

export async function DELETE(req:Request){
  const a=await requireAuth();
  if(!a.ok)return a.response;

  const body=await req.json().catch(()=>({}));
  const id=String(body.id??'').trim();
  if(!id)return NextResponse.json({error:'Brak ID kampanii'},{status:400});

  const campaign=await prisma.affiliateCampaign.findFirst({
    where:{id,userId:a.user.userId},
    select:{id:true}
  });

  if(!campaign){
    return NextResponse.json({error:'Nie znaleziono kampanii'},{status:404});
  }

  await prisma.affiliateCampaign.delete({where:{id:campaign.id}});
  return NextResponse.json({ok:true});
}
