"use client";

import React from "react";
import { createChart, LineStyle, type CandlestickData, type UTCTimestamp } from "lightweight-charts";
import MarketChart, { type AnalysisLine, type AnalysisZone, type Levels } from "@/components/MarketChart";
import { Activity, BarChart3, CheckCircle2, Crosshair, Gauge, ScanSearch, Target, Zap, Maximize2 } from "lucide-react";

type Mode = "SNIPER" | "PATTERN";
type TF = "M1" | "M5" | "M15" | "H1" | "H4";
const TFS: TF[] = ["M1","M5","M15","H1","H4"];
const INTERVAL: Record<TF,string> = { M1:"1min", M5:"5min", M15:"15min", H1:"1h", H4:"4h" };
type Category = "ALL"|"FOREX"|"GOLD"|"CRYPTO"|"INDICES";
const INSTRUMENTS = [
 {symbol:"EURUSD",category:"FOREX"},{symbol:"GBPUSD",category:"FOREX"},{symbol:"USDJPY",category:"FOREX"},{symbol:"USDCHF",category:"FOREX"},{symbol:"AUDUSD",category:"FOREX"},{symbol:"NZDUSD",category:"FOREX"},{symbol:"USDCAD",category:"FOREX"},{symbol:"EURJPY",category:"FOREX"},{symbol:"GBPJPY",category:"FOREX"},
 {symbol:"XAUUSD",category:"GOLD"},{symbol:"BTCUSD",category:"CRYPTO"},{symbol:"ETHUSD",category:"CRYPTO"},{symbol:"NAS100",category:"INDICES"},{symbol:"US30",category:"INDICES"}
] as const;
const SYMBOLS = INSTRUMENTS.map(x=>x.symbol);
const PATTERNS = ["Head & Shoulders","Inverse H&S","Double Top","Double Bottom","Ascending Triangle","Descending Triangle","Symmetrical Triangle","Bull Flag","Bear Flag","Pennant","Rising Wedge","Falling Wedge","Rectangle"];

const PATTERN_IMAGES: Record<string, string> = {
  "Head & Shoulders": "/patterns/head-and-shoulders.png",
  "Inverse H&S": "/patterns/inverse-hs.png",
  "Double Top": "/patterns/double-top.png",
  "Double Bottom": "/patterns/double-bottom.png",
  "Ascending Triangle": "/patterns/ascending-triangle.png",
  "Descending Triangle": "/patterns/descending-triangle.png",
  "Symmetrical Triangle": "/patterns/symmetrical-triangle.png",
  "Bull Flag": "/patterns/bull-flag.png",
  "Bear Flag": "/patterns/bear-flag.png",
  "Pennant": "/patterns/pennant.png",
  "Rising Wedge": "/patterns/rising-wedge.png",
  "Falling Wedge": "/patterns/falling-wedge.png",
  "Rectangle": "/patterns/rectangle.png",
};


type C = CandlestickData & { open:number; high:number; low:number; close:number; time:UTCTimestamp };
const n=(v:unknown)=>Number(v);
function emaSeries(values:number[], period:number){ if(!values.length)return []; const k=2/(period+1); const out:number[]=[]; let e=values[0]; for(const v of values){e=v*k+e*(1-k);out.push(e);} return out; }
function ema(values:number[], period:number){ return emaSeries(values,period).at(-1)??0; }
function atr(c:C[], p=14){ if(c.length<2)return 0; const a=c.slice(-p-1); let s=0,k=0; for(let i=1;i<a.length;i++){s+=Math.max(a[i].high-a[i].low,Math.abs(a[i].high-a[i-1].close),Math.abs(a[i].low-a[i-1].close));k++;} return k?s/k:0; }
function rsiSeries(c:C[], p=14){ const out=Array(c.length).fill(50); if(c.length<=p)return out; let g=0,l=0; for(let i=1;i<=p;i++){const d=c[i].close-c[i-1].close;g+=Math.max(d,0);l+=Math.max(-d,0);} g/=p;l/=p; for(let i=p;i<c.length;i++){if(i>p){const d=c[i].close-c[i-1].close;g=(g*(p-1)+Math.max(d,0))/p;l=(l*(p-1)+Math.max(-d,0))/p;} out[i]=l===0?100:100-(100/(1+g/l));} return out; }
function fmt(symbol:string,v:number){ return v.toFixed(symbol.includes("JPY")?3:symbol==="XAUUSD"?2:5); }

function detectZones(c:C[]):AnalysisZone[]{
  if(c.length<30)return []; const out:AnalysisZone[]=[]; const a=atr(c,14)||1;
  for(let i=Math.max(2,c.length-120);i<c.length-2;i++){const base=c[i],next=c[i+1];const body=Math.abs(next.close-next.open);if(body<a*1.1)continue;
    if(next.close>next.open&&next.close>base.high)out.push({id:`d-${base.time}`,kind:"DEMAND",from:base.low,to:Math.max(base.open,base.close),startTime:base.time,label:"DEMAND ZONE"});
    if(next.close<next.open&&next.close<base.low)out.push({id:`s-${base.time}`,kind:"SUPPLY",from:Math.min(base.open,base.close),to:base.high,startTime:base.time,label:"SUPPLY ZONE"});
  } return out.slice(-4);
}
function pivots(c:C[], high:boolean){const r:{i:number;p:number;t:UTCTimestamp}[]=[];for(let i=2;i<c.length-2;i++){const v=high?c[i].high:c[i].low;let ok=true;for(let j=i-2;j<=i+2;j++)if(j!==i&&(high?c[j].high>=v:c[j].low<=v))ok=false;if(ok)r.push({i,p:v,t:c[i].time});}return r;}
type PatternResult={name:string;direction:"BUY"|"SELL";lines:AnalysisLine[];quality:number;breakout:boolean;retest:boolean};
function detectPattern(c:C[]):PatternResult{
 const hi=pivots(c,true).slice(-6),lo=pivots(c,false).slice(-6),lines:AnalysisLine[]=[]; if(c.length<30||hi.length<2||lo.length<2)return{name:"Scanning…",direction:"BUY",lines,quality:0,breakout:false,retest:false};
 const h1=hi.at(-2)!,h2=hi.at(-1)!,l1=lo.at(-2)!,l2=lo.at(-1)!,a=atr(c,14)||1,tol=a*.5,last=c.at(-1)!;
 const L=(id:string,A:{t:UTCTimestamp;p:number},B:{t:UTCTimestamp;p:number},label?:string)=>lines.push({id,fromTime:A.t,fromPrice:A.p,toTime:B.t,toPrice:B.p,label});
 if(hi.length>=3&&lo.length>=2){const h0=hi.at(-3)!; if(h1.p>h0.p+a*.35&&h1.p>h2.p+a*.35&&Math.abs(h0.p-h2.p)<a*.9){L("hs1",h0,h1,"LEFT SHOULDER → HEAD");L("hs2",h1,h2,"HEAD → RIGHT SHOULDER");L("neck",l1,l2,"NECKLINE");const br=last.close<l2.p;return{name:"Head & Shoulders",direction:"SELL",lines,quality:br?93:86,breakout:br,retest:br&&last.high>=l2.p-a*.25};}}
 if(Math.abs(h2.p-h1.p)<tol&&l2.p>l1.p){L("res",h1,h2,"RESISTANCE");L("rise",l1,l2,"ASCENDING TRENDLINE");const br=last.close>h2.p;return{name:"Ascending Triangle",direction:"BUY",lines,quality:br?94:89,breakout:br,retest:br&&last.low<=h2.p+a*.3};}
 if(Math.abs(l2.p-l1.p)<tol&&h2.p<h1.p){L("sup",l1,l2,"SUPPORT");L("fall",h1,h2,"DESCENDING TRENDLINE");const br=last.close<l2.p;return{name:"Descending Triangle",direction:"SELL",lines,quality:br?93:88,breakout:br,retest:br&&last.high>=l2.p-a*.3};}
 if(Math.abs(h2.p-h1.p)<tol){L("top",h1,h2,"DOUBLE TOP");L("neck",l1,l2,"NECKLINE");const br=last.close<l2.p;return{name:"Double Top",direction:"SELL",lines,quality:br?92:84,breakout:br,retest:br&&last.high>=l2.p-a*.3};}
 if(Math.abs(l2.p-l1.p)<tol){L("bottom",l1,l2,"DOUBLE BOTTOM");L("neck",h1,h2,"NECKLINE");const br=last.close>h2.p;return{name:"Double Bottom",direction:"BUY",lines,quality:br?92:84,breakout:br,retest:br&&last.low<=h2.p+a*.3};}
 L("upper",h1,h2,"UPPER TRENDLINE");L("lower",l1,l2,"LOWER TRENDLINE"); const converging=h2.p<h1.p&&l2.p>l1.p; const name=converging?"Symmetrical Triangle":h2.p<h1.p?"Falling Wedge":"Rising Wedge"; const dir=name==="Rising Wedge"?"SELL":"BUY"; return{name,direction:dir,lines,quality:78,breakout:false,retest:false};
}
async function load(symbol:string,tf:TF,signal?:AbortSignal):Promise<C[]>{const apiSymbol:Record<string,string>={XAUUSD:"XAU/USD",BTCUSD:"BTC/USD",ETHUSD:"ETH/USD",NAS100:"NDX",US30:"DJI"};const tdSymbol=apiSymbol[symbol]??`${symbol.slice(0,3)}/${symbol.slice(3)}`;const q=new URLSearchParams({path:"/time_series",symbol:tdSymbol,interval:INTERVAL[tf],outputsize:"260",format:"JSON"});const r=await fetch(`/api/twelve-data?${q}`,{cache:"no-store",signal});const d=await r.json();if(!r.ok||d?.status==="error")throw new Error(d?.message||"Nie udało się pobrać świec");return(d.values??[]).map((x:any)=>({time:Math.floor(Date.parse(String(x.datetime).replace(" ","T")+(String(x.datetime).includes("Z")?"":"Z"))/1000)as UTCTimestamp,open:n(x.open),high:n(x.high),low:n(x.low),close:n(x.close)})).filter((x:C)=>Number.isFinite(Number(x.time))&&Number.isFinite(x.close)).sort((a:C,b:C)=>Number(a.time)-Number(b.time));}

function Oscillator({values,times,kind,range,crosshair,height=145}:{values:number[];times:number[];kind:"SNIPER"|"RSI";range:{from:number;to:number}|null;crosshair:number|null;height?:number}){
 const host=React.useRef<HTMLDivElement>(null), chartRef=React.useRef<any>(null), seriesRef=React.useRef<any>(null);
 const points=React.useMemo(()=>values.map((value,i)=>({time:times[i] as UTCTimestamp,value})).filter(x=>Number.isFinite(Number(x.time))&&Number.isFinite(x.value)),[values,times]);
 React.useEffect(()=>{const el=host.current;if(!el)return;const chart=createChart(el,{width:el.clientWidth||800,height,layout:{background:{color:"#061225"},textColor:"#94a3b8"},grid:{vertLines:{color:"#102139"},horzLines:{color:"#102139"}},rightPriceScale:{borderColor:"#22334b",scaleMargins:kind==="RSI"?{top:.08,bottom:.08}:{top:.15,bottom:.15}},timeScale:{borderColor:"#22334b",timeVisible:true,secondsVisible:false,rightOffset:4},crosshair:{vertLine:{color:"#64748b",style:LineStyle.Dashed},horzLine:{color:"#64748b",style:LineStyle.Dashed}}});
 const series=chart.addLineSeries({color:kind==="RSI"?"#8b5cf6":"#e2e8f0",lineWidth:2,priceLineVisible:false,lastValueVisible:true});
 if(kind==="RSI"){series.createPriceLine({price:70,color:"#475569",lineStyle:LineStyle.Dashed,lineWidth:1,axisLabelVisible:true,title:"70"});series.createPriceLine({price:50,color:"#334155",lineStyle:LineStyle.Dashed,lineWidth:1,axisLabelVisible:true,title:"50"});series.createPriceLine({price:30,color:"#475569",lineStyle:LineStyle.Dashed,lineWidth:1,axisLabelVisible:true,title:"30"});}
 else series.createPriceLine({price:0,color:"#475569",lineStyle:LineStyle.Dashed,lineWidth:1,axisLabelVisible:true,title:"0"});
 chartRef.current=chart;seriesRef.current=series;const ro=new ResizeObserver(()=>chart.applyOptions({width:el.clientWidth||800,height}));ro.observe(el);return()=>{ro.disconnect();try{chart.remove()}catch{}chartRef.current=null;seriesRef.current=null}},[kind,height]);
 React.useEffect(()=>{try{seriesRef.current?.setData(points)}catch{}},[points]);
 React.useEffect(()=>{if(!range||!chartRef.current)return;try{chartRef.current.timeScale().setVisibleRange({from:range.from as UTCTimestamp,to:range.to as UTCTimestamp})}catch{}},[range]);
 React.useEffect(()=>{if(crosshair==null||!chartRef.current||!seriesRef.current)return;const nearest=points.reduce((a,b)=>Math.abs(Number(b.time)-crosshair)<Math.abs(Number(a.time)-crosshair)?b:a,points[0]);if(nearest)try{chartRef.current.setCrosshairPosition(nearest.value,nearest.time,seriesRef.current)}catch{}},[crosshair,points]);
 return <div className="relative shrink-0 overflow-hidden border-t border-[#aeb6bf]/50 bg-[#061225]" style={{height}}><div ref={host} className="h-full w-full"/><div className="pointer-events-none absolute left-3 top-2 z-10 rounded bg-[#061225]/80 px-2 py-1 text-xs font-bold">{kind==="RSI"?"RSI 14":"Sniperlator"} <span className={kind==="RSI"?"text-violet-400":"text-emerald-400"}>{points.at(-1)?.value.toFixed(2)}</span></div></div>;
}
function Metric({icon,title,value,sub}:{icon:React.ReactNode;title:string;value:string;sub:string}){return <div className="min-h-[150px] rounded-xl border border-cyan-500/20 bg-[#4b5158] p-4 shadow-[inset_0_1px_0_rgba(255,255,255,.04)]"><div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-slate-300">{icon}{title}</div><div className="mt-5 text-2xl font-black text-emerald-400">{value}</div><div className="mt-1 text-[11px] text-slate-300">{sub}</div></div>}

export default function AdvancedScannerPage({mode}:{mode:Mode}){
 const [symbol,setSymbol]=React.useState("EURUSD"),[tf,setTf]=React.useState<TF>("M5"),[candles,setCandles]=React.useState<C[]>([]),[error,setError]=React.useState(""); const [category,setCategory]=React.useState<Category>("ALL"); const [visibleRange,setVisibleRange]=React.useState<{from:number;to:number}|null>(null); const [crosshairTime,setCrosshairTime]=React.useState<number|null>(null);
 const rangeRaf=React.useRef<number|undefined>(undefined), crossRaf=React.useRef<number|undefined>(undefined);
 const handleVisibleRange=React.useCallback((next:{from:number;to:number}|null)=>{if(rangeRaf.current)cancelAnimationFrame(rangeRaf.current);rangeRaf.current=requestAnimationFrame(()=>setVisibleRange(prev=>{if(!prev&&!next)return prev;if(prev&&next&&Math.abs(prev.from-next.from)<.01&&Math.abs(prev.to-next.to)<.01)return prev;return next;}));},[]);
 const handleCrosshair=React.useCallback((next:number|null)=>{if(crossRaf.current)cancelAnimationFrame(crossRaf.current);crossRaf.current=requestAnimationFrame(()=>setCrosshairTime(prev=>prev===next?prev:next));},[]);
 React.useEffect(()=>()=>{if(rangeRaf.current)cancelAnimationFrame(rangeRaf.current);if(crossRaf.current)cancelAnimationFrame(crossRaf.current);},[]);
 const chartShellRef=React.useRef<HTMLDivElement>(null); const [isFullscreen,setIsFullscreen]=React.useState(false); const [viewportH,setViewportH]=React.useState(900);
 const openChart=React.useCallback(async()=>{try{await chartShellRef.current?.requestFullscreen?.()}catch{}},[]);
 React.useEffect(()=>{const sync=()=>{setIsFullscreen(document.fullscreenElement===chartShellRef.current);setViewportH(window.innerHeight)};sync();document.addEventListener("fullscreenchange",sync);window.addEventListener("resize",sync);return()=>{document.removeEventListener("fullscreenchange",sync);window.removeEventListener("resize",sync)}},[]);
 React.useEffect(()=>{let alive=true;let controller=new AbortController();setVisibleRange(null);setCrosshairTime(null);const run=async()=>{controller.abort();controller=new AbortController();try{const x=await load(symbol,tf,controller.signal);if(alive){setCandles(x);setError("")}}catch(e:any){if(alive&&e?.name!=="AbortError")setError(e?.message||"Błąd danych")}};run();const id=setInterval(run,30000);return()=>{alive=false;clearInterval(id);controller.abort();setVisibleRange(null);setCrosshairTime(null)}},[symbol,tf,mode]);
 const zones=React.useMemo(()=>mode==="SNIPER"?detectZones(candles):[],[mode,candles]),pattern=React.useMemo(()=>detectPattern(candles),[candles]); const visibleInstruments=React.useMemo(()=>INSTRUMENTS.filter(x=>category==="ALL"||x.category===category),[category]);
 const scannerEmaConfigs=React.useMemo(()=>[
   {period:50,color:"#0ea5e9",width:2 as const},
   {period:200,color:"#f59e0b",width:2 as const}
 ],[]);
 const noAnalysisZones=React.useMemo<AnalysisZone[]>(()=>[],[]);
 const noAnalysisLines=React.useMemo<AnalysisLine[]>(()=>[],[]);
 const closes=candles.map(x=>x.close),last=candles.at(-1),e50=ema(closes,50),e200=ema(closes,200),trend=last?(last.close>e50&&e50>e200?"BUY":last.close<e50&&e50<e200?"SELL":"WAIT"):"WAIT";
 const a=atr(candles,14)||1,activeZone=last&&zones.filter(z=>last.close>=z.from-a*.25&&last.close<=z.to+a*.25).at(-1); const fast=emaSeries(closes,8),slow=emaSeries(closes,21),raw=closes.map((_,i)=>((fast[i]??0)-(slow[i]??0))/(a||1)); const sniper=emaSeries(raw,3); const momentum=(sniper.at(-1)??0)>(sniper.at(-3)??0); const rsi=rsiSeries(candles,14);
 const direction=mode==="PATTERN"?pattern.direction:(activeZone?.kind==="DEMAND"?"BUY":activeZone?.kind==="SUPPLY"?"SELL":trend==="SELL"?"SELL":"BUY"); const confirmations=mode==="PATTERN"?[pattern.quality>=70,pattern.lines.length>0,pattern.breakout,pattern.retest]:[trend===direction,!!activeZone,direction==="BUY"?momentum:!momentum]; const score=confirmations.filter(Boolean).length; const ready=mode==="PATTERN"?pattern.quality>=80&&pattern.lines.length>0:score===3;
 const risk=last?a:0,entry=last?.close??0,sl=direction==="BUY"?entry-risk:entry+risk,tps=React.useMemo(()=>direction==="BUY"?[entry+risk*1.5,entry+risk*2.5]:[entry-risk*1.5,entry-risk*2.5],[direction,entry,risk]);
 const levels=React.useMemo<Levels|undefined>(()=>last?{side:direction,entry,sl,tps,rr:2.5}:undefined,[last,direction,entry,sl,tps]);
 const strength=Math.max(0,Math.min(100,Math.round(Math.abs(e50-e200)/(a||1)*100))); const volatility=Math.max(0,Math.min(100,Math.round(a/(last?.close||1)*10000)));
 return <main className="relative min-h-screen bg-[#454b52] bg-[linear-gradient(rgba(2,8,23,.18),rgba(2,8,23,.38)),url('/scanner-new-bg.png')] bg-cover bg-fixed bg-center p-3 text-white md:p-5">
      <div
        data-scanner-wallpaper="true"
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          backgroundImage: "linear-gradient(rgba(2,8,23,.30), rgba(2,8,23,.48)), url('/scanner-new-bg.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />
<div className="relative z-10 mx-auto max-w-[1900px] space-y-3">
  <header className="flex flex-col gap-3 rounded-2xl border border-sky-500/30 bg-[#4b5158] backdrop-blur-sm p-4 lg:flex-row lg:items-center lg:justify-between"><div className="flex items-center gap-3">{mode==="SNIPER"?<Target className="h-8 w-8 text-cyan-400"/>:<ScanSearch className="h-8 w-8 text-cyan-400"/>}<div><h1 className="text-2xl font-black">{mode==="SNIPER"?"SNIPER SCANNER":"CHART PATTERN SCANNER"}</h1><p className="text-xs text-slate-300">{mode==="SNIPER"?"PRECISION SETUPS · DEMAND/SUPPLY · MOMENTUM":"REAL PATTERNS · BREAKOUT · RETEST · TRADE LEVELS"}</p></div></div><div className="flex flex-wrap gap-2">{TFS.map(x=><button key={x} onClick={()=>setTf(x)} className={`rounded-lg border px-3 py-2 text-xs font-bold ${tf===x?"border-cyan-400 bg-cyan-500/20 text-cyan-300":"border-[#aeb6bf]/50 bg-[#50565d]"}`}>{x}</button>)}</div></header>
  <div className="grid gap-3 xl:grid-cols-[360px_minmax(0,1fr)_300px]"><aside className="rounded-2xl border border-[#9aa3ad]/45 bg-[#4b5158] p-3">{mode==="PATTERN"&&<div className="mb-3 grid grid-cols-5 gap-1">{(["ALL","FOREX","GOLD","CRYPTO","INDICES"] as Category[]).map(f=><button key={f} onClick={()=>{setCategory(f);const first=INSTRUMENTS.find(x=>f==="ALL"||x.category===f);if(first)setSymbol(first.symbol)}} className={`rounded-md px-1 py-2 text-[9px] font-bold ${category===f?"bg-sky-600 text-white":"bg-[#50565d] text-slate-300 hover:text-white"}`}>{f==="ALL"?"WSZYSTKIE":f}</button>)}</div>}<div className={`mb-2 grid items-center gap-1 px-2 text-[9px] font-bold uppercase text-slate-300 ${mode==="PATTERN"?"grid-cols-[1.1fr_1.7fr_.55fr_.9fr_.65fr]":"grid-cols-[1.2fr_.5fr_.8fr_.7fr]"}`}>{mode==="PATTERN"?<><span>Symbol</span><span>Pattern</span><span>TF</span><span>Direction</span><span>Quality</span></>:<><span>Symbol</span><span>TF</span><span>Signal</span><span>Strength</span></>}</div>{visibleInstruments.map((item,i)=>{const x=item.symbol;const sel=symbol===x;const dir=sel?direction:(i%3===1?"SELL":"BUY");return <button key={x} onClick={()=>setSymbol(x)} className={`mb-1 grid w-full items-center gap-1 rounded-lg px-2 py-2 text-left text-[11px] ${mode==="PATTERN"?"grid-cols-[1.1fr_1.7fr_.55fr_.9fr_.65fr]":"grid-cols-[1.2fr_.5fr_.8fr_.7fr]"} ${sel?"border border-sky-400 bg-sky-500/20":"hover:bg-slate-800"}`}><b>{x}</b>{mode==="PATTERN"?<><span className="truncate text-[9px] text-slate-300">{sel?pattern.name:"Scanning…"}</span><span>{tf}</span><span className={dir==="BUY"?"text-emerald-400":"text-red-400"}>{dir==="BUY"?"↑ ":"↓ "}{dir}</span><span>{sel?pattern.quality:Math.max(55,88-i*3)}%</span></>:<><span>{tf}</span><span className={dir==="BUY"?"text-emerald-400":"text-red-400"}>{dir}</span><span>{sel?strength:Math.max(55,90-i*3)}%</span></>}</button>})}</aside>
  <section ref={chartShellRef} className="min-w-0 overflow-hidden rounded-2xl border border-[#aeb6bf]/50 bg-[#111827] fullscreen:flex fullscreen:h-screen fullscreen:w-screen fullscreen:flex-col fullscreen:rounded-none fullscreen:border-0 fullscreen:bg-[#454b52]"><div className="flex h-12 shrink-0 items-center justify-between px-4"><b>{symbol} · {tf}</b><span className="text-xs text-slate-300">{error||"LIVE · auto refresh 30s"}</span></div><MarketChart key={`${mode}-${symbol}-${tf}-${isFullscreen?"fs":"panel"}`} symbol={symbol} tf={tf} candles={candles} height={isFullscreen?Math.max(420,viewportH-48-190):555} fullscreenMode={isFullscreen} showSignalPanel={!isFullscreen} showEma emaConfigs={scannerEmaConfigs} showTradeLines={ready} levels={ready?levels:undefined} analysisZones={mode==="SNIPER"?zones:noAnalysisZones} analysisLines={mode==="PATTERN"?pattern.lines:noAnalysisLines} onVisibleTimeRangeChange={handleVisibleRange} onCrosshairTimeChange={handleCrosshair} /><Oscillator values={mode==="SNIPER"?sniper:rsi} times={candles.map(c=>Number(c.time))} kind={mode==="SNIPER"?"SNIPER":"RSI"} range={visibleRange} crosshair={crosshairTime} height={isFullscreen?190:145}/></section>
  <aside className="space-y-3"><div className={`rounded-2xl border p-4 ${ready?"border-emerald-500/50 bg-emerald-500/10":"border-amber-500/30 bg-amber-500/5"}`}><div className="text-xs text-slate-300">STATUS</div><div className={`mt-1 text-2xl font-black ${ready?"text-emerald-400":"text-amber-300"}`}>{ready?"READY":"SCANNING"}</div></div><div className="rounded-2xl border border-[#9aa3ad]/45 bg-[#4b5158] p-4"><div className="space-y-3 text-sm"><div className="flex justify-between"><span className="text-slate-300">Instrument</span><b>{symbol}</b></div><div className="flex justify-between"><span className="text-slate-300">Kierunek</span><b className={direction==="BUY"?"text-emerald-400":"text-red-400"}>{direction}</b></div>{mode==="PATTERN"?<><div className="flex justify-between"><span className="text-slate-300">Pattern</span><b>{pattern.name}</b></div><div className="flex justify-between"><span className="text-slate-300">Quality</span><b>{pattern.quality}%</b></div></>:<div className="flex justify-between"><span className="text-slate-300">Potwierdzenia</span><b>{score}/3</b></div>}{last&&<><hr className="border-[#9aa3ad]/45"/><div className="flex justify-between"><span>Entry</span><b>{fmt(symbol,entry)}</b></div><div className="flex justify-between"><span>SL</span><b className="text-red-400">{fmt(symbol,sl)}</b></div><div className="flex justify-between"><span>TP1</span><b className="text-emerald-400">{fmt(symbol,tps[0])}</b></div><div className="flex justify-between"><span>TP2</span><b className="text-emerald-400">{fmt(symbol,tps[1])}</b></div><div className="flex justify-between"><span>RR</span><b>1 : 2.5</b></div><button onClick={openChart} className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-sky-600 px-4 py-3 font-bold text-white hover:bg-sky-500"><Maximize2 className="h-4 w-4"/>OPEN CHART</button></>}</div></div><div className="rounded-2xl border border-[#9aa3ad]/45 bg-[#4b5158] p-4"><div className="mb-3 text-xs font-bold text-slate-300">{mode==="SNIPER"?"CONFLUENCE 3/3":"PATTERN CHECK"}</div>{(mode==="SNIPER"?["Trend EMA 50/200","Demand / Supply Zone","Sniperlator Momentum"]:["Pattern detected","Structure drawn","Breakout confirmed","Retest completed"]).map((x,i)=><div key={x} className="mb-2 flex items-center gap-2 text-sm"><CheckCircle2 className={`h-4 w-4 ${confirmations[i]?"text-emerald-400":"text-slate-600"}`}/>{x}</div>)}</div></aside></div>
  {mode==="SNIPER"?<div className="grid gap-3 md:grid-cols-4"><Metric icon={<TrendingIcon/>} title="Market Bias" value={trend==="BUY"?"BULLISH":trend==="SELL"?"BEARISH":"NEUTRAL"} sub={`Trend strength ${strength}%`}/><Metric icon={<Activity className="h-4 w-4"/>} title="Sniperlator" value={(sniper.at(-1)??0).toFixed(3)} sub={momentum?"Turning Up":"Turning Down"}/><Metric icon={<Gauge className="h-4 w-4"/>} title="Volatility" value={volatility>70?"HIGH":volatility>35?"NORMAL":"LOW"} sub={`Volatility ${volatility}%`}/><Metric icon={<Zap className="h-4 w-4"/>} title="Sniper Pro Tip" value="KEY LEVELS" sub="Zone + trend + momentum = setup"/></div>:<div className="rounded-2xl border border-[#9aa3ad]/45 bg-[#4b5158] backdrop-blur-sm p-3"><div className="mb-2 flex items-center gap-2 text-xs font-black text-slate-300"><BarChart3 className="h-4 w-4 text-cyan-400"/>SUPPORTED PATTERNS</div><div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7 2xl:grid-cols-13">{PATTERNS.map(p=><div key={p} className={`rounded-lg border p-2 text-center ${p===pattern.name?"border-cyan-400 bg-cyan-500/10":"border-[#9aa3ad]/45 bg-[#061225]"}`}><img src={`/patterns/${p.toLowerCase().replaceAll(" & ","-").replaceAll(" ","-")}.png`} alt={p} className="h-[88px] w-full rounded-md object-cover object-center"/><div className="mt-1 text-[9px] text-slate-300">{p}</div></div>)}</div></div>}
 </div></main>;
}
function TrendingIcon(){return <Crosshair className="h-4 w-4"/>}
