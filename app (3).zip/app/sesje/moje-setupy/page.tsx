"use client";

import Link from "next/link";
import { ArrowLeft, CheckCircle2, Crosshair, Plus, Search, Target, TrendingUp } from "lucide-react";

const setups = [
  { instrument: "GOLD", side: "BUY", tf: "M5", entry: "3328.40", sl: "3322.80", tp: "3339.60", rr: "1:2.0", status: "AKTYWNY" },
  { instrument: "DJ30", side: "SELL", tf: "M5", entry: "41482", sl: "41528", tp: "41390", rr: "1:2.0", status: "OCZEKUJE" },
  { instrument: "EURUSD", side: "BUY", tf: "M1", entry: "1.1284", sl: "1.1269", tp: "1.1314", rr: "1:2.0", status: "ZAKOŃCZONY" },
  { instrument: "BTC", side: "BUY", tf: "M5", entry: "118420", sl: "117860", tp: "119540", rr: "1:2.0", status: "OCZEKUJE" },
];

export default function MojeSetupyPage() {
  return (
    <main className="min-h-screen bg-[#020914] text-white">
      <div className="mx-auto w-full max-w-[1750px] px-4 py-5 md:px-6 xl:px-8">
        <header className="rounded-[18px] border border-amber-500/35 bg-[linear-gradient(135deg,rgba(120,53,15,.25),rgba(4,12,23,.96))] p-5"><div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"><div className="flex items-center gap-4"><Link href="/sesje" className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-700 bg-[#081522]"><ArrowLeft className="h-5 w-5" /></Link><div className="flex h-14 w-14 items-center justify-center rounded-full border border-amber-400/45 bg-amber-500/10 text-amber-300"><Crosshair className="h-8 w-8" /></div><div><div className="text-[9px] font-bold uppercase tracking-[.22em] text-amber-300/70">FX TRADE PROFESSIONAL</div><h1 className="mt-1 text-3xl font-black">MOJE <span className="text-amber-300">SETUPY</span></h1><p className="mt-1 text-[11px] text-slate-400">Zapisane pomysły transakcyjne, Entry / SL / TP i kontrola RR.</p></div></div><button className="inline-flex items-center justify-center gap-2 rounded-xl border border-amber-300/30 bg-[linear-gradient(90deg,#b96b08,#f59e0b)] px-5 py-3 text-[10px] font-black"><Plus className="h-4 w-4" /> DODAJ SETUP</button></div></header>

        <section className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">{[["AKTYWNE","3",TrendingUp,"text-emerald-300"],["OCZEKUJĄCE","5",Target,"text-sky-300"],["ZAKOŃCZONE","18",CheckCircle2,"text-violet-300"],["ŚREDNIE RR","1:2.1",Crosshair,"text-amber-300"]].map(([label,value,Icon,color]) => { const I=Icon as typeof TrendingUp; return <div key={String(label)} className="rounded-[14px] border border-slate-700/70 bg-[#06111d] p-4"><div className="flex items-center gap-3"><div className={`flex h-11 w-11 items-center justify-center rounded-xl border border-slate-700 bg-[#081522] ${color}`}><I className="h-5 w-5" /></div><div><div className="text-[8px] text-slate-500">{String(label)}</div><div className="mt-1 text-2xl font-black">{String(value)}</div></div></div></div>})}</section>

        <section className="mt-4 rounded-[15px] border border-slate-700/70 bg-[#06111d] p-4"><div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><div className="flex flex-1 items-center gap-2 rounded-xl border border-slate-700 bg-[#030b14] px-3 py-2.5"><Search className="h-4 w-4 text-slate-500" /><input className="w-full bg-transparent text-[10px] outline-none placeholder:text-slate-600" placeholder="Szukaj setupu..." /></div><div className="flex gap-2"><button className="rounded-xl border border-slate-700 bg-[#081522] px-4 py-2.5 text-[9px] font-bold text-slate-300">WSZYSTKIE</button><button className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-2.5 text-[9px] font-bold text-emerald-300">AKTYWNE</button></div></div></section>

        <section className="mt-4 grid gap-4 xl:grid-cols-2">{setups.map((s) => <article key={`${s.instrument}-${s.entry}`} className="rounded-[16px] border border-slate-700/70 bg-[linear-gradient(145deg,#071522,#030a12)] p-5"><div className="flex items-start justify-between"><div><div className="flex items-center gap-2"><h2 className="text-xl font-black">{s.instrument}</h2><span className={`rounded-md px-2 py-1 text-[8px] font-black ${s.side === "BUY" ? "bg-emerald-500/10 text-emerald-300 border border-emerald-500/25" : "bg-rose-500/10 text-rose-300 border border-rose-500/25"}`}>{s.side}</span><span className="rounded-md border border-slate-700 bg-[#07131f] px-2 py-1 text-[8px] font-bold text-slate-400">{s.tf}</span></div><div className="mt-1 text-[9px] text-slate-500">Setup zapisany do analizy</div></div><span className="rounded-md border border-amber-500/25 bg-amber-500/10 px-2 py-1 text-[8px] font-black text-amber-300">{s.status}</span></div><div className="mt-5 grid grid-cols-4 gap-2">{[["ENTRY",s.entry,"text-sky-300"],["STOP LOSS",s.sl,"text-rose-300"],["TAKE PROFIT",s.tp,"text-emerald-300"],["RR",s.rr,"text-amber-300"]].map(([k,v,c]) => <div key={k} className="rounded-xl border border-slate-800 bg-[#040c15] p-3"><div className="text-[7px] text-slate-500">{k}</div><div className={`mt-1 text-[12px] font-black ${c}`}>{v}</div></div>)}</div><div className="mt-4 h-28 rounded-xl border border-slate-800 bg-[linear-gradient(180deg,#041019,#02070b)] p-3"><svg viewBox="0 0 400 90" className="h-full w-full text-amber-400"><path d="M0 72 30 66 60 70 90 52 120 57 150 42 180 46 210 31 240 39 270 24 300 30 330 18 360 23 400 8" fill="none" stroke="currentColor" strokeWidth="2"/></svg></div><button className="mt-4 w-full rounded-xl border border-amber-400/25 bg-amber-500/10 px-4 py-2.5 text-[10px] font-black text-amber-300">OTWÓRZ SETUP</button></article>)}</section>
      </div>
    </main>
  );
}

