import { Worker } from "node:worker_threads";
import { io } from "socket.io-client";
import dotenv from "dotenv";
import http from "node:http";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { getCollectorSymbols, normalizeMarketSymbol, toLiveRatesSymbol } from "../lib/market/master-symbols";
import { LiveCandleEngine } from "../lib/market/live-candle-engine";
import { historyDrainPolicy } from "../lib/market/history-drain-policy";

dotenv.config({ path: ".env.local" });
dotenv.config({ path: ".env" });

// Worker owns the only PrismaClient for history writes.
let sqlWorker: Worker | null = null;
let workerRequestId = 0;
let inFlight: { id: number; resolve: () => void; reject: (error: Error) => void } | null = null;
function rejectInFlight(error: Error) {
  const current = inFlight;
  inFlight = null;
  if (current) current.reject(error);
}
function ensureSqlWorker(): Worker {
  if (sqlWorker) return sqlWorker;
  const workerFile = path.join(process.cwd(), "scripts", "history-sql-worker.cjs");
  if (!fs.existsSync(workerFile)) throw new Error(`Missing HISTORY SQL worker: ${workerFile}`);
  const worker = new Worker(workerFile);
  sqlWorker = worker;
  worker.on("message", (message: { type?: string; id?: number; ok?: boolean; error?: string }) => {
    if (message?.type !== "result" || !inFlight || message.id !== inFlight.id) return;
    const current = inFlight;
    inFlight = null;
    if (message.ok) current.resolve();
    else current.reject(new Error(message.error || "HISTORY SQL write failed"));
  });
  worker.on("error", (error) => {
    if (sqlWorker === worker) sqlWorker = null;
    rejectInFlight(error);
  });
  worker.on("exit", (code) => {
    if (sqlWorker === worker) sqlWorker = null;
    rejectInFlight(new Error(`HISTORY worker exited with code ${code}`));
  });
  return worker;
}
const key = process.env.LIVE_RATES_API_KEY;
if (!key) throw new Error("Missing LIVE_RATES_API_KEY");

// Stage 2C: opt-in SQLite mode. Legacy WAL is left untouched when enabled.
const HISTORY_STORAGE = process.env.OHLC_HISTORY_STORAGE || "legacy";
if (!["legacy", "sqlite"].includes(HISTORY_STORAGE)) throw new Error("Invalid OHLC_HISTORY_STORAGE");
const SQLITE_MODE = HISTORY_STORAGE === "sqlite";
const HISTORY_PAUSED = process.env.HISTORY_PAUSED !== "false";
// The bridge is CommonJS-loaded dynamically by tsx only in SQLite mode.
// Node 24 handles node:sqlite in the isolated worker.
let historyBridge: any = null;
let sqliteReady = false;
let sqliteError: string | null = null;
let sqliteAccepted = 0;
let sqliteQueued = 0;
let sqliteLastCommittedAt: number | null = null;
const SQLITE_MAX_WAITING = 5000;
let sqliteSerial = Promise.resolve();
async function initHistory() {
  if (!SQLITE_MODE) return;
  // @ts-ignore - the tested worker bridge is an ESM .mjs module.
  const mod = await import("./history-bridge.mjs");
  const file = process.env.OHLC_HISTORY_SQLITE_PATH || "/data/ohlc-history/history.sqlite";
  historyBridge = new mod.HistoryBridge({ filename: file, maxPendingTicks: SQLITE_MAX_WAITING });
  await historyBridge.ready;
  sqliteReady = true;
  console.log(`[MASTER] SQLite history ready: ${file}; legacy WAL preserved, SQL disabled`);
}

const PORT = Number(process.env.PORT || 8080);
const PROVIDER_INSTRUMENTS = getCollectorSymbols(process.env.LIVE_RATES_INSTRUMENTS);
const PROVIDER_SET = new Set(PROVIDER_INSTRUMENTS);
const LIVE_RATES_SUBSCRIPTIONS = Array.from(new Set(PROVIDER_INSTRUMENTS.map(toLiveRatesSymbol)));

const frames = [
  ["1min", 60_000], ["5min", 300_000], ["15min", 900_000],
  ["30min", 1_800_000], ["1h", 3_600_000], ["4h", 14_400_000], ["1day", 86_400_000],
] as const;

type Tick = { symbol: string; price: number; timestamp: number };
type TickBatch = { symbol: string; interval: string; bucket: number; open: number; high: number; low: number; close: number; firstAt: number; lastAt: number; ticks: number };

const latestTicks: Record<string, Tick> = {};
const liveCandleEngine = new LiveCandleEngine();
// Reject out-of-order events that would overwrite the latest candle close.
const lastAcceptedTimestamp = new Map<string, number>();
let staleTicksRejected = 0;
const staleTicksBySymbol = new Map<string, number>();
const acceptedTicksBySymbol = new Map<string, number>();
let invalidTimestampsRejected = 0;
let futureTimestampsRejected = 0;
let invalidPricesRejected = 0;
let shutdownFlushFailed = false;
// FAZA 3.0.1: passive diagnostics. No changes to tick acceptance or SQL writes.
let acceptedTicks = 0;
let lastAcceptedTickAt: number | null = null;
let lastProviderTickTimestamp: number | null = null;
let maxProviderTickLagMs = 0;
let lastProviderTickLagMs: number | null = null;
const acceptedByMinute = new Map<number, Set<string>>();
// FAZA 3.0.3: provider-arrival monitoring (independent of accepted tick timestamps).
let lastProviderPriceArrivalAt: number | null = null;
let marketDataGapEvents = 0;
let longestProviderSilenceMs = 0;
let lastProviderGapMs: number | null = null;
const PROVIDER_GAP_THRESHOLD_MS = 30_000;
let tickArrivalLagMs: number | null = null;
let maxTickArrivalLagMs = 0;
let negativeTickArrivalLagCount = 0;
function observeProviderPrice(timestamp: number) {
  const now = Date.now();
  if (lastProviderPriceArrivalAt !== null) {
    const gap = now - lastProviderPriceArrivalAt;
    if (gap >= PROVIDER_GAP_THRESHOLD_MS) {
      marketDataGapEvents++;
      lastProviderGapMs = gap;
      longestProviderSilenceMs = Math.max(longestProviderSilenceMs, gap);
      console.warn(`[MASTER] provider price arrival gap: ${gap}ms`);
    }
  }
  lastProviderPriceArrivalAt = now;
  tickArrivalLagMs = now - timestamp;
  maxTickArrivalLagMs = Math.max(maxTickArrivalLagMs, tickArrivalLagMs);
  if (tickArrivalLagMs < 0) negativeTickArrivalLagCount++;
}

function recordAcceptedTick(t: Tick) {
  acceptedTicks++;
  acceptedTicksBySymbol.set(t.symbol, (acceptedTicksBySymbol.get(t.symbol) || 0) + 1);
  lastAcceptedTickAt = Date.now();
  lastProviderTickTimestamp = t.timestamp;
  lastProviderTickLagMs = Date.now() - t.timestamp;
  maxProviderTickLagMs = Math.max(maxProviderTickLagMs, lastProviderTickLagMs);
  const minute = Math.floor(t.timestamp / 60_000) * 60_000;
  let symbols = acceptedByMinute.get(minute);
  if (!symbols) { symbols = new Set<string>(); acceptedByMinute.set(minute, symbols); }
  symbols.add(t.symbol);
  const cutoff = Date.now() - 30 * 60_000;
  for (const k of acceptedByMinute.keys()) if (k < cutoff) acceptedByMinute.delete(k);
}
function oldestQueueBucket() {
  let oldest = Infinity;
  for (const b of pending.values()) oldest = Math.min(oldest, b.bucket);
  for (const chunk of retryChunks) for (const row of chunk) oldest = Math.min(oldest, row.batch.bucket);
  return Number.isFinite(oldest) ? oldest : null;
}
function ingestionDiagnostics() {
  const oldest = oldestQueueBucket();
  return {
    providerSilenceSeconds: lastProviderPriceArrivalAt === null ? null : Math.floor((Date.now() - lastProviderPriceArrivalAt) / 1000),
    marketDataGapEvents, lastProviderGapMs, longestProviderSilenceMs,
    tickArrivalLagMs, maxTickArrivalLagMs, negativeTickArrivalLagCount,
    lastProviderPriceArrivalAt,
    acceptedTicks, lastAcceptedTickAt, lastProviderTickTimestamp,
    lastProviderTickLagMs, maxProviderTickLagMs,
    oldestQueuedBucket: oldest,
    oldestQueuedBucketAgeMs: oldest === null ? null : Date.now() - oldest,
    acceptedMinuteCoverage: [...acceptedByMinute.entries()].sort((a,b)=>b[0]-a[0]).slice(0, 15)
      .map(([minute, symbols]) => ({ minute, symbols: symbols.size })),
  };
}
const MAX_FUTURE_TICK_MS = 60_000;

const clientsBySymbol = new Map<string, Set<http.ServerResponse>>();
const pending = new Map<string, TickBatch>();
// Immutable failed chunks keep stable IDs for idempotent SQL retries.
const retryChunks: Array<Array<{ id: string; batch: TickBatch }>> = [];
// Synchronous, crash-safe checkpoint on the mounted Railway Volume.
// Checkpoint BEFORE acknowledging a tick or submitting SQL, preserving stable ledger IDs.
const QUEUE_DIR = process.env.OHLC_QUEUE_DIR || "/data/ohlc-queue";
const QUEUE_FILE = path.join(QUEUE_DIR, "state.json");
// V2.1: small fsynced append-only WAL per tick; large snapshots only at flush boundaries.
const WAL_FILE = path.join(QUEUE_DIR, "ticks.wal");
let walSequence = 0;
let walBytes = 0;
let walRecoveredTicks = 0;
let lastWalSyncMs: number | null = null;
const MAX_WAL_BYTES = 16 * 1024 * 1024;
const MAX_QUEUE_BYTES = 64 * 1024 * 1024;
let queueCheckpointAt: number | null = null;
let queueCheckpointBytes = 0;
let lastQueueCheckpointMs: number | null = null;
let maxQueueCheckpointMs = 0;
let slowQueueCheckpoints = 0;
let queueRecoveredRows = 0;
let queueFatalError: string | null = null;

function validateBatch(value: any): value is TickBatch {
  return !!value && typeof value.symbol === "string" && typeof value.interval === "string" &&
    [value.bucket, value.open, value.high, value.low, value.close, value.firstAt, value.lastAt, value.ticks]
      .every((n: unknown) => typeof n === "number" && Number.isFinite(n)) &&
    value.bucket > 0 && value.firstAt > 0 && value.lastAt >= value.firstAt &&
    value.open > 0 && value.close > 0 && value.high >= Math.max(value.open, value.close) &&
    value.low <= Math.min(value.open, value.close) && value.ticks > 0;
}

function saveQueue(): void {
  const checkpointStarted = Date.now();
  const payload = JSON.stringify({ version: 2, walSequence, pending: [...pending.entries()], retryChunks });
  const bytes = Buffer.byteLength(payload);
  if (bytes > MAX_QUEUE_BYTES) throw new Error(`OHLC queue exceeds 64 MiB (${bytes} bytes)`);
  const tmp = `${QUEUE_FILE}.${process.pid}.tmp`;
  try {
    const fd = fs.openSync(tmp, "w", 0o600);
    try { fs.writeFileSync(fd, payload); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, QUEUE_FILE);
    // Ensure the directory entry survives a host crash where supported.
    const dirfd = fs.openSync(QUEUE_DIR, "r");
    try { fs.fsyncSync(dirfd); } finally { fs.closeSync(dirfd); }
    // Snapshot is now durable. WAL records <= walSequence are covered by it.
    // A crash before WAL truncation is safe: recovery skips those sequences.
    const walFd = fs.openSync(WAL_FILE, fs.existsSync(WAL_FILE) ? "r+" : "w+", 0o600);
    try { fs.ftruncateSync(walFd, 0); fs.fsyncSync(walFd); } finally { fs.closeSync(walFd); }
    walBytes = 0;
    queueCheckpointAt = Date.now();
    queueCheckpointBytes = bytes;
    lastQueueCheckpointMs = Date.now() - checkpointStarted;
    maxQueueCheckpointMs = Math.max(maxQueueCheckpointMs, lastQueueCheckpointMs);
    if (lastQueueCheckpointMs > 250) {
      slowQueueCheckpoints++;
      if (slowQueueCheckpoints <= 5 || slowQueueCheckpoints % 100 === 0)
        console.warn(`[MASTER] slow durable queue checkpoint: ${lastQueueCheckpointMs}ms, bytes=${bytes}, pending=${pending.size}, retries=${retryChunks.length}`);
    }
  } catch (err) {
    try { fs.unlinkSync(tmp); } catch {}
    throw err;
  }
}

function recoverQueue(): void {
  fs.mkdirSync(QUEUE_DIR, { recursive: true });
  if (!fs.existsSync(QUEUE_FILE)) {
    if (fs.existsSync(WAL_FILE) && fs.statSync(WAL_FILE).size > 0)
      throw new Error("WAL exists but state.json is missing; refusing unsafe recovery");
    saveQueue(); return;
  }
  const state = JSON.parse(fs.readFileSync(QUEUE_FILE, "utf8"));
  if (![1, 2].includes(state?.version) || !Array.isArray(state.pending) || !Array.isArray(state.retryChunks))
    throw new Error("Invalid OHLC durable queue version or structure");
  for (const entry of state.pending) {
    if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string" || !validateBatch(entry[1]) || entry[0] !== batchKey(entry[1]))
      throw new Error("Corrupt OHLC pending entry");
    if (pending.has(entry[0])) throw new Error("Duplicate OHLC pending key");
    pending.set(entry[0], entry[1]);
  }
  const recoveredIds = new Set<string>();
  for (const chunk of state.retryChunks) {
    if (!Array.isArray(chunk) || !chunk.every((row: any) => row && typeof row.id === "string" && validateBatch(row.batch)))
      throw new Error("Corrupt OHLC retry chunk");
    for (const row of chunk) {
      if (recoveredIds.has(row.id)) throw new Error("Duplicate durable batch ID");
      recoveredIds.add(row.id);
    }
    retryChunks.push(chunk);
  }
  walSequence = state.version === 2 ? state.walSequence : 0;
  if (!Number.isSafeInteger(walSequence) || walSequence < 0) throw new Error("Invalid WAL sequence");
  if (fs.existsSync(WAL_FILE)) {
    let raw = fs.readFileSync(WAL_FILE, "utf8");
    // Never silently discard an incomplete record: it may contain an acknowledged tick.
    // Preserve the WAL intact for inspection or recovery from the external backup.
    if (raw.length && !raw.endsWith("\n"))
      throw new Error("Incomplete WAL tail; refusing automatic truncation to protect queued ticks");
    walBytes = Buffer.byteLength(raw);
    const lines = raw.split("\n");
    // A final partial record can be caused by a crash during append; ignore only that tail.
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i]) continue;
      let entry: { seq: number; tick: Tick; sha256?: string };
      try { entry = JSON.parse(lines[i]); }
      catch (e) { throw new Error(`Invalid WAL JSON at line ${i + 1}`); }
      if (!Number.isSafeInteger(entry.seq) || entry.seq <= 0 ||
          !entry.tick || typeof entry.tick.symbol !== "string" ||
          !Number.isFinite(entry.tick.price) || entry.tick.price <= 0 ||
          !Number.isFinite(entry.tick.timestamp) || entry.tick.timestamp <= 0)
        throw new Error("Invalid durable WAL record");
      if (entry.sha256 !== undefined) {
        const expected = crypto.createHash("sha256")
          .update(JSON.stringify({ seq: entry.seq, tick: entry.tick })).digest("hex");
        if (entry.sha256 !== expected) throw new Error(`WAL checksum mismatch at line ${i + 1}`);
      }
      if (entry.seq <= walSequence) continue;
      if (entry.seq !== walSequence + 1) throw new Error("WAL sequence gap");
      aggregateTick(entry.tick);
      walSequence = entry.seq;
      walRecoveredTicks++;
    }
  }
  queueRecoveredRows = pending.size + retryChunks.reduce((n, c) => n + c.length, 0);
  queueCheckpointBytes = fs.statSync(QUEUE_FILE).size;
  queueCheckpointAt = Date.now();
  console.log(`[MASTER] durable OHLC queue recovered ${queueRecoveredRows} rows from ${QUEUE_FILE}`);
}

function fatalQueueError(error: unknown): never {
  queueFatalError = error instanceof Error ? error.message : String(error);
  console.error("[MASTER] FATAL durable OHLC queue error; stopping to avoid unprotected writes", queueFatalError);
  // Do not process any further provider events after a failed durable write.
  socket.disconnect();
  process.exit(1);
}

let flushTimer: NodeJS.Timeout | null = null;
let dbWriting = false;
// V2.2: in-flight diagnostics; no changes to WAL, batch identity or SQL semantics.
let dbSqlStartedAt: number | null = null;
let dbSqlRowsInFlight = 0;
let dbFlushStartedAt: number | null = null;
let liveRatesConnected = false;
let providerInfo = "";
let providerError = "";
const unrecognizedSymbols = new Map<string, number>();
const receivedCount = new Map<string, number>();
let failedDbWrites = 0;
let successfulDbWrites = 0;
let lastDbWriteMs: number | null = null;
let lastDbSuccessAt: number | null = null;
let lastDbFailureAt: number | null = null;
let consecutiveDbFailures = 0;
// V2: aggregate incoming ticks for longer before creating immutable SQL chunks.
// The durable queue is still checkpointed on every accepted tick, so this
// does not discard tick data. Configure OHLC_DB_FLUSH_MS on Railway if needed.
// 60s default reduces repeated UPSERTs of the same active candle compared
// with the previous 15s interval. Existing retry chunks are never rewritten.
const DB_FLUSH_MS = Math.max(15_000, Math.min(120_000, Number(process.env.OHLC_DB_FLUSH_MS || 60_000) || 60_000));
// Fewer database round-trips. Existing durable retry chunks retain their original IDs.
// Keep bounded to avoid excessively large SQL statements.
const DB_CHUNK_ROWS = Math.max(1, Math.min(64, Number(process.env.OHLC_DB_CHUNK_ROWS || 42) || 42));
// V2: adaptive sizing applies ONLY to newly created chunks. Persisted retry
// chunks retain their exact contents and IDs to preserve ledger idempotency.
const DB_MIN_CHUNK_ROWS = Math.min(DB_CHUNK_ROWS, 12);
let adaptiveChunkRows = DB_CHUNK_ROWS;
let consecutiveFastBatches = 0;
let slowDbBatches = 0;
let adaptiveReductions = 0;
let adaptiveIncreases = 0;
const DB_SLOW_MS = 5000;
const DB_FAST_MS = 1500;
const DB_MAX_FLUSH_WORK_MS = 12000;
let lastDbSqlMs: number | null = null;
let lastDbCheckpointMs: number | null = null;
let maxDbSqlMs = 0;
let lastDbBatchRows = 0;
let lastDbBatchAt: number | null = null;
const DB_RETRY_MAX_MS = 60000;
let shuttingDown = false;
// Bounded, sanitized diagnostics; never expose API keys or complete raw payloads.
const rawEventCounts = new Map<string, number>();
const rawSymbolCounts = new Map<string, number>();
const rawMessageShapes = new Map<string, number>();
let lastRateAt: number | null = null;
let lastConnectAt: number | null = null;
let lastDisconnectAt: number | null = null;
const forexSlashSubscriptions = process.env.LIVE_RATES_FOREX_SLASH === "true";
function summarizeRawRate(raw: unknown) {
  const msg = typeof raw === "string" ? JSON.parse(raw) : raw;
  if (Array.isArray(msg)) { rawMessageShapes.set("array", (rawMessageShapes.get("array") || 0) + 1); return msg; }
  if (!msg || typeof msg !== "object") { rawMessageShapes.set(typeof msg, (rawMessageShapes.get(typeof msg) || 0) + 1); return []; }
  const shape = Object.keys(msg).filter(k => !/key|token|secret|auth/i.test(k)).sort().join(",").slice(0, 180);
  rawMessageShapes.set(shape, (rawMessageShapes.get(shape) || 0) + 1);
  return [msg];
}
function logRawSymbol(rawSymbol: string) {
  const safe = rawSymbol.slice(0, 40).replace(/[^A-Za-z0-9/_-]/g, "");
  if (!safe) return;
  const count = (rawSymbolCounts.get(safe) || 0) + 1;
  rawSymbolCounts.set(safe, count);
  if (count === 1) console.log(`[MASTER] incoming Live Rates symbol: ${safe} -> ${normalizeMarketSymbol(safe)}`);
}
function providerSubscriptions() {
  if (!forexSlashSubscriptions) return LIVE_RATES_SUBSCRIPTIONS;
  return LIVE_RATES_SUBSCRIPTIONS.map(s => /^[A-Z]{6}$/.test(s) && !["BTCUSD", "ETHUSD", "XAUUSD", "XAGUSD"].includes(s) ? `${s.slice(0, 3)}/${s.slice(3)}` : s);
}


function clientSet(symbol: string) {
  let set = clientsBySymbol.get(symbol);
  if (!set) { set = new Set(); clientsBySymbol.set(symbol, set); }
  return set;
}
function totalClients() { let n=0; for (const s of clientsBySymbol.values()) n+=s.size; return n; }
function normalizeTimestamp(value: unknown): number | null {
  // Never fabricate candle timestamps from invalid provider data.
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n < 10_000_000_000 ? n * 1000 : n;
}

function batchKey(b: Pick<TickBatch, "symbol" | "interval" | "bucket">) {
  return `${b.symbol}|${b.interval}|${b.bucket}`;
}

function mergeBatch(a: TickBatch, b: TickBatch): TickBatch {
  return {
    ...a,
    high: Math.max(a.high, b.high),
    low: Math.min(a.low, b.low),
    open: a.firstAt <= b.firstAt ? a.open : b.open,
    close: a.lastAt >= b.lastAt ? a.close : b.close,
    firstAt: Math.min(a.firstAt, b.firstAt),
    lastAt: Math.max(a.lastAt, b.lastAt),
    ticks: a.ticks + b.ticks,
  };
}

function scheduleFlush(delayMs = DB_FLUSH_MS) {
  if (!flushTimer && !shuttingDown) {
    flushTimer = setTimeout(() => { flushTimer = null; void flushDb(); }, delayMs);
  }
}

function aggregateTick(t: Tick) {
  // Aggregate by the *actual* candle bucket, not just by symbol.
  // A batch crossing 1m/5m/etc boundaries must never be assigned to one candle.
  for (const [interval, size] of frames) {
    const bucket = Math.floor(t.timestamp / size) * size;
    const incoming: TickBatch = {
      symbol: t.symbol, interval, bucket, open: t.price, high: t.price,
      low: t.price, close: t.price, firstAt: t.timestamp,
      lastAt: t.timestamp, ticks: 1,
    };
    const k = batchKey(incoming);
    const existing = pending.get(k);
    pending.set(k, existing ? mergeBatch(existing, incoming) : incoming);
  }
}

function queueDbTick(t: Tick) {
  try {
    // Checkpoint first, then derive the next sequence from the durable state.
    // Include a checksum for new records; legacy WAL lines remain readable.
    const nextBytesEstimate = Buffer.byteLength(JSON.stringify({ seq: walSequence + 1, tick: t, sha256: "0".repeat(64) }) + "\n");
    if (walBytes + nextBytesEstimate > MAX_WAL_BYTES) saveQueue();
    const seq = walSequence + 1;
    const sha256 = crypto.createHash("sha256").update(JSON.stringify({ seq, tick: t })).digest("hex");
    const record = JSON.stringify({ seq, tick: t, sha256 }) + "\n";
    const bytes = Buffer.byteLength(record);
    const started = Date.now();
    const fd = fs.openSync(WAL_FILE, "a", 0o600);
    try { fs.writeFileSync(fd, record); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    lastWalSyncMs = Date.now() - started;
    walBytes += bytes;
    walSequence = seq;
    aggregateTick(t);
    // Publish LIVE only after the tick has been fsynced to the WAL.
    liveCandleEngine.accept(t);
  } catch (e) { fatalQueueError(e); }
  if (!SQLITE_MODE && !HISTORY_PAUSED) scheduleFlush();
}

type DurableBatch = { id: string; batch: TickBatch };

async function writeBatches(rows: DurableBatch[]): Promise<void> {
  if (!rows.length) return;
  const worker = ensureSqlWorker();
  if (inFlight) throw new Error("HISTORY worker already has an in-flight SQL batch");
  await new Promise<void>((resolve, reject) => {
    const id = ++workerRequestId;
    inFlight = { id, resolve, reject };
    try { worker.postMessage({ type: "write", id, rows }); }
    catch (error) { rejectInFlight(error instanceof Error ? error : new Error(String(error))); }
  });
}

async function flushDb() {
  if (SQLITE_MODE || HISTORY_PAUSED) return;
  if (dbWriting) return;
  dbWriting = true;
  const flushStarted = Date.now();
  dbFlushStartedAt = flushStarted;
  try {
    // Retry immutable failed chunks first. Never merge them with fresh ticks.
    const snapshot = [...pending.entries()];
    pending.clear();
    const newChunks: DurableBatch[][] = [];
    const chunkRowsForThisFlush = adaptiveChunkRows;
    for (let i = 0; i < snapshot.length; i += chunkRowsForThisFlush) {
      newChunks.push(snapshot.slice(i, i + chunkRowsForThisFlush).map(([, batch]) => ({ id: crypto.randomUUID(), batch })));
    }
    retryChunks.push(...newChunks);
    // Stable batch IDs must reach disk before any SQL request.
    try { saveQueue(); } catch (e) { fatalQueueError(e); }
    // V4: bounded HISTORY pass; LIVE ingestion remains independent of SQL progress.
    const decision = historyDrainPolicy({
      queuedRows: retryChunks.reduce((total, chunk) => total + chunk.length, 0),
      sqlFailures: consecutiveDbFailures,
      lastSqlMs: lastDbSqlMs,
      liveTickLagMs: lastProviderTickLagMs,
      shuttingDown,
    });
    let chunksProcessed = 0;
    while (retryChunks.length && chunksProcessed < decision.maxChunksPerPass) {
      const part = retryChunks[0];
      const started = Date.now();
      dbSqlStartedAt = started;
      dbSqlRowsInFlight = part.length;
      try {
        await writeBatches(part);
        const sqlFinished = Date.now();
        lastDbSqlMs = sqlFinished - started;
        maxDbSqlMs = Math.max(maxDbSqlMs, lastDbSqlMs);
        lastDbBatchRows = part.length;
        lastDbBatchAt = sqlFinished;
        retryChunks.shift();
        chunksProcessed++;
        // SQL is committed. If we crash before checkpoint, ledger deduplicates replay.
        const checkpointStarted = Date.now();
        try { saveQueue(); } catch (e) { fatalQueueError(e); }
        lastDbCheckpointMs = Date.now() - checkpointStarted;
        lastDbWriteMs = Date.now() - started;
        lastDbSuccessAt = Date.now();
        successfulDbWrites++;
        consecutiveDbFailures = 0;
        if (lastDbSqlMs > DB_SLOW_MS) {
          slowDbBatches++;
          consecutiveFastBatches = 0;
          const smaller = Math.max(DB_MIN_CHUNK_ROWS, Math.floor(adaptiveChunkRows / 2));
          if (smaller < adaptiveChunkRows) {
            adaptiveChunkRows = smaller;
            adaptiveReductions++;
            console.warn(`[MASTER] adaptive DB chunk reduced to ${adaptiveChunkRows} after ${lastDbSqlMs}ms SQL`);
          }
        } else if (lastDbSqlMs < DB_FAST_MS) {
          consecutiveFastBatches++;
          if (consecutiveFastBatches >= 12 && adaptiveChunkRows < DB_CHUNK_ROWS) {
            adaptiveChunkRows = Math.min(DB_CHUNK_ROWS, adaptiveChunkRows + 4);
            adaptiveIncreases++;
            consecutiveFastBatches = 0;
          }
        } else {
          consecutiveFastBatches = 0;
        }
        if (lastDbSqlMs > 5000 || lastDbCheckpointMs > 1000)
          console.warn(`[MASTER] slow DB upsert: sql=${lastDbSqlMs}ms, checkpoint=${lastDbCheckpointMs}ms, total=${lastDbWriteMs}ms, rows=${part.length}, retryChunks=${retryChunks.length}, pending=${pending.size}`);
        // Yield between chunks during overload. Keep all remaining chunks durable.
        if (!shuttingDown && Date.now() - flushStarted >= DB_MAX_FLUSH_WORK_MS) break;
      } catch (e: any) {
        failedDbWrites++;
        consecutiveDbFailures++;
        lastDbFailureAt = Date.now();
        lastDbWriteMs = Date.now() - started;
        console.error(`[MASTER] DB batch failed; queued retry (${part.length} rows), duration=${lastDbWriteMs}ms`, e?.message || e);
        break;
      }
    }
  } finally {
    dbWriting = false;
    dbSqlStartedAt = null;
    dbSqlRowsInFlight = 0;
    dbFlushStartedAt = null;
    if (pending.size || retryChunks.length) {
      const decision = historyDrainPolicy({
        queuedRows: pending.size + retryChunks.reduce((total, chunk) => total + chunk.length, 0),
        sqlFailures: consecutiveDbFailures,
        lastSqlMs: lastDbSqlMs,
        liveTickLagMs: lastProviderTickLagMs,
        shuttingDown,
      });
      scheduleFlush(Math.max(decision.delayMs, consecutiveDbFailures ? Math.min(DB_RETRY_MAX_MS, DB_FLUSH_MS) : 0));
    }
  }
}

function broadcastTick(t: Tick) {
  const body=`event: tick\ndata: ${JSON.stringify(t)}\n\n`;
  for (const c of clientSet(t.symbol)) try { c.write(body); } catch { clientSet(t.symbol).delete(c); }
}
function broadcastStatus(payload: unknown) {
  const body=`event: status\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const set of clientsBySymbol.values()) for (const c of set) try { c.write(body); } catch { set.delete(c); }
}

const socket=io("https://wss.live-rates.com",{transports:["websocket"],reconnection:true,reconnectionAttempts:Infinity,reconnectionDelay:5000,reconnectionDelayMax:30000,randomizationFactor:.5,forceNew:true,multiplex:false,autoConnect:false,timeout:20000});
socket.on("connect",()=>{ lastConnectAt=Date.now(); liveRatesConnected=true; providerError=""; console.log(`[MASTER] connected; subscribing ${providerSubscriptions().length} symbols (forexSlash=${forexSlashSubscriptions})`); socket.emit("instruments",providerSubscriptions()); socket.emit("key",{key}); broadcastStatus({provider:"live-rates",connected:true,mode:"MASTER_150"}); });
socket.on("rates",(raw:any)=>{ try {
  lastRateAt = Date.now();
  for (const msg of summarizeRawRate(raw)) {
    if (msg?.info) { providerInfo=String(msg.info);broadcastStatus({provider:"live-rates",connected:liveRatesConnected,info:providerInfo,mode:"MASTER_150"});continue; }
    if (msg?.error) { providerError=String(msg.error);broadcastStatus({provider:"live-rates",connected:liveRatesConnected,error:providerError,mode:"MASTER_150"});continue; }
    const rawSymbol=String(msg?.currency??msg?.symbol??"");
    logRawSymbol(rawSymbol);
    const symbol=normalizeMarketSymbol(rawSymbol);
    if(!PROVIDER_SET.has(symbol)) { if(rawSymbol){const count=(unrecognizedSymbols.get(rawSymbol)||0)+1;unrecognizedSymbols.set(rawSymbol,count);if(count===1) console.warn(`[MASTER] ignored provider symbol ${rawSymbol.slice(0,40)} -> ${symbol} (not subscribed)`);} continue; }
    receivedCount.set(symbol,(receivedCount.get(symbol)||0)+1);
    const price=Number(msg?.bid??msg?.price);
    if(!Number.isFinite(price)||price<=0){ invalidPricesRejected++; continue; }
    const timestamp=normalizeTimestamp(msg?.timestamp);
    if(timestamp === null){ invalidTimestampsRejected++; continue; }
    observeProviderPrice(timestamp);
    if(timestamp > Date.now() + MAX_FUTURE_TICK_MS){ futureTimestampsRejected++; continue; }
    const last=lastAcceptedTimestamp.get(symbol);
    if(last !== undefined && timestamp < last){ staleTicksRejected++; staleTicksBySymbol.set(symbol, (staleTicksBySymbol.get(symbol) || 0) + 1); continue; }
    const tick={symbol,price,timestamp};
    if (SQLITE_MODE) {
      if (shuttingDown || sqliteError) return;
      // Acknowledge/publish only after SQLite transaction commits. Serialize provider
      // events to preserve ordering, and never create new legacy SQL retry chunks.
      if (sqliteQueued >= SQLITE_MAX_WAITING) {
        sqliteError = "SQLite input backlog exceeded safe bound";
        console.error("[MASTER]", sqliteError);
        socket.disconnect();
        shuttingDown = true;
        process.exitCode = 1;
        return;
      }
      sqliteQueued++;
      sqliteSerial = sqliteSerial.then(async () => {
        try {
          if (sqliteError) return;
          const prev = lastAcceptedTimestamp.get(symbol);
          if (prev !== undefined && timestamp < prev) return;
          await historyBridge.ticks([tick]);
          lastAcceptedTimestamp.set(symbol,timestamp);
          latestTicks[symbol]=tick;
          liveCandleEngine.accept(tick);
          recordAcceptedTick(tick);
          broadcastTick(tick);
          sqliteAccepted++;
          sqliteLastCommittedAt = Date.now();
        } finally { sqliteQueued--; }
      }).catch((error: unknown) => {
        sqliteError = error instanceof Error ? error.message : String(error);
        console.error("[MASTER] SQLite commit failed; stopping stream without publishing uncommitted ticks", sqliteError);
        socket.disconnect();
        // A failed history write must not silently resume on reconnection.
        shuttingDown = true;
        process.exitCode = 1;
      });
    } else {
      // Legacy mode remains unchanged until migration is explicitly enabled.
      queueDbTick(tick);
      lastAcceptedTimestamp.set(symbol,timestamp);
      latestTicks[symbol]=tick;
      recordAcceptedTick(tick);
      broadcastTick(tick);
    }
  }
} catch(e){console.error("[MASTER] parse",e);} });
// Count event names only, not raw payloads (which might contain credentials).
socket.onAny((event:string)=>{ rawEventCounts.set(event,(rawEventCounts.get(event)||0)+1); });
// Socket.IO automatically retries transport failures, but an explicit server-side
// disconnect ("io server disconnect") disables automatic reconnection. Reconnect
// that case ourselves, without creating another socket or another API-key session.
let providerReconnectTimer: NodeJS.Timeout | null = null;
function scheduleProviderReconnect(delayMs = 5000) {
  if (shuttingDown || providerReconnectTimer || socket.connected) return;
  providerReconnectTimer = setTimeout(() => {
    providerReconnectTimer = null;
    if (!shuttingDown && !socket.connected) {
      console.warn("[MASTER] retrying Live-Rates streaming connection");
      socket.connect();
    }
  }, delayMs);
  providerReconnectTimer.unref();
}
socket.on("disconnect", reason => {
  lastDisconnectAt = Date.now();
  liveRatesConnected = false;
  broadcastStatus({provider:"live-rates",connected:false,reason,mode:"MASTER_150"});
  if (reason === "io server disconnect") scheduleProviderReconnect();
});
socket.on("connect_error", e => {
  liveRatesConnected = false;
  providerError = e.message;
  console.error("[MASTER] connect", e.message);
});
// Backstop for a connection that remains down despite Socket.IO's own retries.
// Only one socket is ever used, so the provider's one-connection-per-key rule holds.
const providerReconnectWatchdog = setInterval(() => {
  if (!shuttingDown && !socket.connected && !socket.active)
    scheduleProviderReconnect(1000);
}, 30_000);
providerReconnectWatchdog.unref();

const server=http.createServer((req,res)=>{
  const origin=req.headers.origin||"*"; res.setHeader("Access-Control-Allow-Origin",origin);res.setHeader("Vary","Origin");res.setHeader("Access-Control-Allow-Methods","GET, OPTIONS");res.setHeader("Access-Control-Allow-Headers","Content-Type");
  if(req.method==="OPTIONS"){res.writeHead(204);res.end();return;}
  const url=new URL(req.url||"/",`http://${req.headers.host||"localhost"}`);
  if (url.pathname === "/api/market/history") {
    if (!SQLITE_MODE || !sqliteReady) { res.writeHead(503,{"Content-Type":"application/json"});res.end(JSON.stringify({ok:false,error:"SQLite history not enabled"}));return; }
    const secret=process.env.OHLC_LIVE_READ_TOKEN;
    if (secret && req.headers["x-ohlc-live-token"] !== secret) {res.writeHead(401);res.end();return;}
    const symbol=normalizeMarketSymbol(url.searchParams.get("symbol")||"");
    const interval=url.searchParams.get("interval")||"1min";
    const limit=Math.min(2000,Math.max(1,Number(url.searchParams.get("limit")||500)));
    const before=Number(url.searchParams.get("before")||Date.now());
    if (!PROVIDER_SET.has(symbol) || !frames.some(f=>f[0]===interval) || !Number.isSafeInteger(before) || !Number.isFinite(limit)) {
      res.writeHead(400,{"Content-Type":"application/json"});res.end(JSON.stringify({ok:false,error:"Invalid history query"}));return;
    }
    void historyBridge.read(symbol,interval,limit,before).then((result:any)=>{
      res.writeHead(200,{"Content-Type":"application/json","Cache-Control":"no-store"});
      res.end(JSON.stringify({ok:true,source:"collector-sqlite",symbol,interval,candles:result.rows}));
    }).catch((error:unknown)=>{
      res.writeHead(503,{"Content-Type":"application/json"});res.end(JSON.stringify({ok:false,error:"History temporarily unavailable"}));
      console.error("[MASTER] SQLite history read",error);
    });return;
  }
  // V4: independent, read-only LIVE OHLC view. Never mutates WAL or retry chunks.
  if(url.pathname==="/api/market/live-candles") {
    const secret=process.env.OHLC_LIVE_READ_TOKEN;
    if(secret && req.headers["x-ohlc-live-token"]!==secret){res.writeHead(401);res.end();return;}
    const symbol=normalizeMarketSymbol(url.searchParams.get("symbol")||"");
    const interval=url.searchParams.get("interval")||"1min";
    const frame=frames.find(f=>f[0]===interval);
    if(!PROVIDER_SET.has(symbol)||!frame){res.writeHead(400,{"Content-Type":"application/json"});res.end(JSON.stringify({status:"error",message:"Invalid symbol or interval"}));return;}
    const now=Date.now();
    const currentBucket=Math.floor(now/frame[1])*frame[1];
    // Independent live state: no retry queue scan and no SQL dependency.
    const live = liveCandleEngine.current(symbol, interval as import("../lib/market/live-candle-engine").LiveInterval, now);
    res.writeHead(200,{"Content-Type":"application/json","Cache-Control":"no-store"});
    res.end(JSON.stringify({status:"ok",source:"collector-memory",symbol,interval,
      connected:liveRatesConnected,generatedAt:new Date(now).toISOString(),
      lastTickAgeMs:live?now-live.lastAt:null,
      candle:live?{datetime:new Date(live.bucket).toISOString().replace("T"," ").slice(0,19),
        open:String(live.open),high:String(live.high),low:String(live.low),
        close:String(live.close),volume:String(live.ticks),firstAt:live.firstAt,lastAt:live.lastAt}:null}));return;
  }
  if(url.pathname==="/health/quick") {
    res.writeHead(200,{"Content-Type":"application/json","Cache-Control":"no-store"});
    res.end(JSON.stringify({ok:!sqliteError,connected:liveRatesConnected,historyStorage:HISTORY_STORAGE,historyPaused:HISTORY_PAUSED,sqliteReady,sqliteQueued,sqliteAccepted,sqliteLastCommittedAt,sqliteError,dbWriting,
      pendingRows:pending.size,retryChunks:retryChunks.length,liveCandles:liveCandleEngine.size,
      successfulDbWrites,failedDbWrites,lastDbSqlMs,lastDbSuccessAt,
      walBytes,walSequence,walRecoveredTicks,lastWalSyncMs,
      checkpointAt:queueCheckpointAt,checkpointBytes:queueCheckpointBytes}));return;
  }
  if(url.pathname==="/health"){res.writeHead(200,{"Content-Type":"application/json","Cache-Control":"no-store"});res.end(JSON.stringify({ok:true,mode:"MASTER_150",connected:liveRatesConnected,configured:PROVIDER_INSTRUMENTS.length,providerSubscriptions:providerSubscriptions(),forexSlashSubscriptions,diagnostics:{rawEventCounts:Object.fromEntries(rawEventCounts),rawSymbolCounts:Object.fromEntries(rawSymbolCounts),rawMessageShapes:Object.fromEntries(rawMessageShapes),lastRateAt,lastConnectAt,lastDisconnectAt},clients:totalClients(),receivedSymbols:Object.keys(latestTicks).length,latestTicks,dbWriting,dbPending:[...new Set([...pending.values()].map(b=>b.symbol))],dbPendingRows:pending.size,dbRetryRows:retryChunks.reduce((n,c)=>n+c.length,0),durableQueue:{directory:QUEUE_DIR,checkpointAt:queueCheckpointAt,checkpointBytes:queueCheckpointBytes,lastCheckpointMs:lastQueueCheckpointMs,maxCheckpointMs:maxQueueCheckpointMs,slowCheckpoints:slowQueueCheckpoints,recoveredRows:queueRecoveredRows,walBytes,walSequence,walRecoveredTicks,lastWalSyncMs,fatalError:queueFatalError},dbMetrics:{version:"2.2-diagnostics",dbSqlStartedAt,dbSqlAgeMs:dbSqlStartedAt===null?null:Date.now()-dbSqlStartedAt,dbSqlRowsInFlight,dbFlushStartedAt,dbFlushAgeMs:dbFlushStartedAt===null?null:Date.now()-dbFlushStartedAt,flushMs:DB_FLUSH_MS,chunkRows:DB_CHUNK_ROWS,adaptiveChunkRows,slowDbBatches,adaptiveReductions,adaptiveIncreases,successfulDbWrites,failedDbWrites,consecutiveDbFailures,lastDbWriteMs,lastDbSqlMs,lastDbCheckpointMs,maxDbSqlMs,lastDbBatchRows,lastDbBatchAt,lastDbSuccessAt,lastDbFailureAt,shutdownFlushFailed},ingestionDiagnostics:ingestionDiagnostics(),ohlcMetrics:{staleTicksRejected,staleTicksBySymbol:Object.fromEntries(staleTicksBySymbol),acceptedTicksBySymbol:Object.fromEntries(acceptedTicksBySymbol),invalidTimestampsRejected,futureTimestampsRejected,invalidPricesRejected,activeCandles:[...pending.values()].filter(b=>b.bucket+Number(frames.find(f=>f[0]===b.interval)?.[1]??0)>Date.now()).length,closedPendingCandles:[...pending.values()].filter(b=>b.bucket+Number(frames.find(f=>f[0]===b.interval)?.[1]??0)<=Date.now()).length},providerInfo:providerInfo||null,providerError:providerError||null,failedDbWrites,receivedCount:Object.fromEntries(receivedCount),unrecognizedSymbols:Object.fromEntries(unrecognizedSymbols),missingConfiguredSymbols:PROVIDER_INSTRUMENTS.filter(s=>!latestTicks[s])}));return;}
  const m=url.pathname.match(/^\/api\/(?:market\/)?([a-z0-9]+)\/stream$/i);
  if(m){ const symbol=normalizeMarketSymbol(m[1]); if(!PROVIDER_SET.has(symbol)){res.writeHead(404,{"Content-Type":"application/json"});res.end(JSON.stringify({ok:false,error:"Unknown symbol"}));return;} res.writeHead(200,{"Content-Type":"text/event-stream; charset=utf-8","Cache-Control":"no-cache, no-transform",Connection:"keep-alive","X-Accel-Buffering":"no","Access-Control-Allow-Origin":origin,Vary:"Origin"});res.write("retry: 3000\n\n");res.write(`event: status\ndata: ${JSON.stringify({provider:"live-rates",connected:liveRatesConnected,symbol,mode:"MASTER_150"})}\n\n`);if(latestTicks[symbol])res.write(`event: tick\ndata: ${JSON.stringify(latestTicks[symbol])}\n\n`);const set=clientSet(symbol);set.add(res);const keep=setInterval(()=>{try{res.write(`: keepalive ${Date.now()}\n\n`);}catch{}},15000);req.on("close",()=>{clearInterval(keep);set.delete(res);});return; }
  res.writeHead(200,{"Content-Type":"application/json"});res.end(JSON.stringify({ok:true,service:"FX Trade Master Market Collector",mode:"MASTER_150",configured:PROVIDER_INSTRUMENTS.length,health:"/health",streamPattern:"/api/market/{symbol}/stream"}));
});
// Fail startup if the persistent volume is absent, read-only, or contains invalid data.
// SQLite mode does not read, modify, truncate, or replay the old /data/ohlc-queue.
if (!SQLITE_MODE) {
  try { recoverQueue(); } catch (e) { fatalQueueError(e); }
}
void initHistory().then(() => server.listen(PORT,"0.0.0.0",()=>{
  console.log(`[MASTER] HTTP/SSE :${PORT}; OHLC flush=${DB_FLUSH_MS}ms; chunk max=${DB_CHUNK_ROWS}`);
  if (!SQLITE_MODE && !HISTORY_PAUSED && (pending.size || retryChunks.length)) scheduleFlush(1000);
  socket.connect();
})).catch(error => { console.error("[MASTER] History initialization failed", error); process.exit(1); });
async function shutdown(signal:string){
  if (shuttingDown) return;
  console.log(`[MASTER] ${signal}: stopping LIVE; preserving durable OHLC queue`);
  shuttingDown = true;
  if (providerReconnectTimer) { clearTimeout(providerReconnectTimer); providerReconnectTimer = null; }
  clearInterval(providerReconnectWatchdog);
  socket.removeAllListeners("rates");
  socket.disconnect();
  if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }

  // A durable checkpoint includes all pending and retry rows, even if SQL is in flight.
  // Never remove an in-flight retry chunk unless the worker confirmed SQL commit.
  try { if (!SQLITE_MODE) saveQueue(); }
  catch (error) {
    shutdownFlushFailed = true;
    console.error("[MASTER] shutdown checkpoint failed", error);
  }

  // Give an existing SQL write a bounded chance to finish. Do not initiate a new
  // database request during shutdown: Railway may terminate the process mid-query.
  const waitUntil = Date.now() + 20_000;
  while (dbWriting && Date.now() < waitUntil)
    await new Promise(resolve => setTimeout(resolve, 100));
  if (dbWriting) {
    shutdownFlushFailed = true;
    console.error("[MASTER] SQL still in flight; durable retry chunk retained for ledger-safe replay");
  }

  // If a commit completed while waiting, persist the updated retry queue again.
  try { if (!SQLITE_MODE) saveQueue(); }
  catch (error) {
    shutdownFlushFailed = true;
    console.error("[MASTER] final shutdown checkpoint failed", error);
  }
  if (!SQLITE_MODE && (pending.size || retryChunks.length)) {
    console.warn(`[MASTER] ${pending.size} pending candles and ${retryChunks.length} retry chunks remain durable for restart`);
  }

  if (SQLITE_MODE) {
    await sqliteSerial;
    if (historyBridge) try { await historyBridge.close(); } catch (error) { shutdownFlushFailed = true; console.error("[MASTER] SQLite shutdown failed", error); }
  }
  for (const set of clientsBySymbol.values()) for (const c of set) try { c.end(); } catch {}
  await new Promise<void>(resolve => server.close(() => resolve()));
  // Only terminate an idle worker. An unfinished write is left to process shutdown;
  // its durable retry ID is intentionally preserved for idempotent replay.
  if (!dbWriting && sqlWorker) await sqlWorker.terminate();
  process.exit(shutdownFlushFailed ? 1 : 0);
}

process.on("SIGINT",()=>void shutdown("SIGINT"));process.on("SIGTERM",()=>void shutdown("SIGTERM"));
