"use client";

import React from "react";
import { translations, type TranslationKey } from "@/lib/i18n";
import {
  languages,
  normalizeLanguage,
  translateExact,
  type AppLanguage,
} from "@/lib/i18n/catalog";

type LanguageContextValue = {
  lang: AppLanguage;
  setLang: (lang: AppLanguage) => void;
  t: (key: TranslationKey) => string;
  tText: (text: string) => string;
  locale: string;
};

const LanguageContext = React.createContext<LanguageContextValue | null>(null);

function persistLanguage(lang: AppLanguage) {
  localStorage.setItem("lang", lang);
  localStorage.setItem("fxtrade-language", lang);
  document.cookie = `fxtrade-language=${lang}; path=/; max-age=31536000; samesite=lax`;
}

export function LanguageProvider({
  children,
  initialLanguage = "pl",
}: {
  children: React.ReactNode;
  initialLanguage?: AppLanguage;
}) {
  const [lang, setLangState] = React.useState<AppLanguage>(initialLanguage);

  React.useEffect(() => {
    // initialLanguage comes from the server cookie.
    // After router.refresh() it is the authoritative value and must not
    // be overwritten by a stale client-side value.
    const next = normalizeLanguage(initialLanguage);
    setLangState(next);
    document.documentElement.lang = next;
    persistLanguage(next);
  }, [initialLanguage]);

  const setLang = React.useCallback((nextLang: AppLanguage) => {
    persistLanguage(nextLang);
    setLangState(nextLang);
    document.documentElement.lang = nextLang;
  }, []);

  React.useEffect(() => {
    const syncLanguage = (event: Event) => {
      const custom = event as CustomEvent<string>;
      const raw = custom.detail ?? localStorage.getItem("fxtrade-language") ?? localStorage.getItem("lang") ?? "pl";
      const next = normalizeLanguage(raw);
      setLangState(next);
      document.documentElement.lang = next;
    };
    const syncStorage = (event: StorageEvent) => {
      if (event.key !== "lang" && event.key !== "fxtrade-language") return;
      const next = normalizeLanguage(event.newValue ?? "pl");
      setLangState(next);
      document.documentElement.lang = next;
    };
    window.addEventListener("fxtrade-language-change", syncLanguage as EventListener);
    window.addEventListener("storage", syncStorage);
    return () => {
      window.removeEventListener("fxtrade-language-change", syncLanguage as EventListener);
      window.removeEventListener("storage", syncStorage);
    };
  }, []);

  const t = React.useCallback(
    (key: TranslationKey) => translations[lang]?.[key] ?? translations.pl[key] ?? key,
    [lang]
  );

  const tText = React.useCallback(
    (text: string) => translateExact(text, lang) ?? text,
    [lang]
  );

  const locale = languages.find((item) => item.code === lang)?.locale ?? "pl-PL";

  const value = React.useMemo(
    () => ({ lang, setLang, t, tText, locale }),
    [lang, setLang, t, tText, locale]
  );

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = React.useContext(LanguageContext);

  if (!context) {
    throw new Error("useLanguage must be used inside LanguageProvider");
  }

  return context;
}
